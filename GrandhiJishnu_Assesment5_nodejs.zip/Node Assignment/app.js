const express=require('express')
const app=express()
//to extract body from request
var bodyparser=require('body-parser')
const port=3001;
app.use(bodyparser.urlencoded({extended:true}))
app.set('view engine','ejs')
var fs=require("fs")


app.get("/about",function(req,res){
    
var fileData=fs.readFileSync("resources/about.txt","utf8")
console.log(fileData);


    res.render("about",{fileData:fileData})
})

app.listen(port,function(){
    console.log(`server started on ${port}`)
})
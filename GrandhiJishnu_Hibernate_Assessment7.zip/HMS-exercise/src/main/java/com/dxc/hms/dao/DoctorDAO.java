package com.dxc.hms.dao;

import java.util.List;

import com.dxc.hms.model.Doctor;



public interface DoctorDAO {

	public Doctor getDoctor(int id);
	public Doctor getDoctorByName(String name);

	public List<Doctor> getAllDoctors();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int id);
	public void updateDoctor(Doctor doctor);
	public boolean isDoctorExists(int id);
}

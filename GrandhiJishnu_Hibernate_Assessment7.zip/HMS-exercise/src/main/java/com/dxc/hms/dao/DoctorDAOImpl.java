package com.dxc.hms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.hms.model.Doctor;
import com.dxc.hms.util.HibernateUtil;






public class DoctorDAOImpl implements DoctorDAO {
	SessionFactory sf=HibernateUtil.getSessionFactory();
	public void addDoctor(Doctor doctor) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getName()+"saved successfully");
		
	}

	public Doctor getDoctor(int id) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class,id);
		return doctor;
	
	}

	public Doctor getDoctorByName(String name) {
		Session session=sf.openSession();
		Query query=session.createQuery("from Doctor D where d.name ="+name);
		return (Doctor) query.list();
		
	}

	public List<Doctor> getAllDoctors() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Doctor");
		return query.list();
		
	}

	

	public void deleteDoctor(int id) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Doctor doctor=new Doctor();
		doctor.setId(id);
		session.delete(doctor);
		transaction.commit();
		session.close();
		
	}

	public void updateDoctor(Doctor newDoctor) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		
		session.update(newDoctor);
		transaction.commit();
		session.close();
		
	}

	public boolean isDoctorExists(int id) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class,id);
		if(doctor==null)
		return false;
		else 
			return true;
		
	}

	

	


}

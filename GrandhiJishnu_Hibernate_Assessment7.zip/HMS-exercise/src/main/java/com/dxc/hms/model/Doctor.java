package com.dxc.hms.model;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.search.annotations.IndexedEmbedded;
@Entity
public class Doctor {
	@Id
	private int id;
	private String name;
	private int fees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails> hospitaldetails;
	public Doctor() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public Set<HospitalDetails> getHospitaldetails() {
		return hospitaldetails;
	}
	public void setHospitaldetails(Set<HospitalDetails> hospitaldetails) {
		this.hospitaldetails = hospitaldetails;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fees;
		result = prime * result + ((hospitaldetails == null) ? 0 : hospitaldetails.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (fees != other.fees)
			return false;
		if (hospitaldetails == null) {
			if (other.hospitaldetails != null)
				return false;
		} else if (!hospitaldetails.equals(other.hospitaldetails))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	public Doctor(int id, String name, int fees, Set<HospitalDetails> hospitaldetails) {
		super();
		this.id = id;
		this.name = name;
		this.fees = fees;
		this.hospitaldetails = hospitaldetails;
	}
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", fees=" + fees + ", hospitaldetails=" + hospitaldetails + "]";
	}
	
	
}

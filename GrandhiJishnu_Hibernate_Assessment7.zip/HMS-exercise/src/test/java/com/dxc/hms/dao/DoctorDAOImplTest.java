package com.dxc.hms.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.hms.model.Doctor;
import com.dxc.hms.model.HospitalDetails;


import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	DoctorDAOImpl impl;
	protected void setUp() throws Exception{
		impl=new DoctorDAOImpl();
	
	}
	public void testGetAllDoctors() {
		List<Doctor> doctor=impl.getAllDoctors();
		assertNotNull(doctor);
		
	}
	
	  public void testAddDoctor() 
	  {
		  List<Doctor>allDoc1=impl.getAllDoctors();
	HospitalDetails hos=new HospitalDetails("rahm","aj");
	Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
	hds.add(hos);
	Doctor doctor=new Doctor(21, "jhu", 311,hds);
	
	impl.addDoctor(doctor);
	  List<Doctor>allDoc2=impl.getAllDoctors();
	  assertNotSame(allDoc2.size(),allDoc1.size()); 
	  }
	  
	  public void testGetDoctor() {
		  HospitalDetails hos=new HospitalDetails("rahm","aj");
			Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
			hds.add(hos);
			Doctor doctor=new Doctor(121, "jhhu", 311,hds);
			
			impl.addDoctor(doctor);
			Doctor newDoc=impl.getDoctor(121);
			assertNotNull(newDoc);
	  }
	  
	  
	  
	  
	  
	  
	  
	  public void testDeleteDoctor() {
		  HospitalDetails hos=new HospitalDetails("rahm","aj");
			Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
			hds.add(hos);
			Doctor doctor=new Doctor(121, "jhhu", 311,hds);
			
			impl.addDoctor(doctor);
			 List<Doctor>allDoc1=impl.getAllDoctors();
		  impl.deleteDoctor(121);
		  List<Doctor>allDoc2=impl.getAllDoctors();
		  assertNotSame(allDoc1, allDoc2);
		  
	  }
	  
	  public void testUpdateDoctor() 
	  { 
		  HospitalDetails hos=new HospitalDetails("rahm","aj");
			Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
			hds.add(hos);
			Doctor doctor=new Doctor(121, "jhhu", 311,hds);
			
			impl.addDoctor(doctor);
			Doctor doctor1=new Doctor(121, "jhhu", 311,hds);
			impl.updateDoctor(doctor1);
			assertNotSame(doctor1, doctor);
	  }
	  
	  public void testIsDoctorExists() { 
		  HospitalDetails hos=new HospitalDetails("rahm","aj");
			Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
			hds.add(hos);
			Doctor doctor=new Doctor(121, "jhhu", 311,hds);
			
			impl.addDoctor(doctor);
			assertEquals(true, impl.isDoctorExists(121));
		  
	  }
	 

}

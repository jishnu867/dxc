import React, { Component } from 'react';
import ListProductComponent from './components/ListProductComponent';
import './App.css'
import {BrowserRouter as Router} from 'react-router-dom'
import{Switch,Route} from 'react-router-dom'
import ProductComponent from './components/ProductComponent';
import DisplayComponent from './components/DisplayComponent';
import SearchComponent from './components/SearchComponent'

class App extends Component {
  render() {
    return (
      <div className="App">
        <h1>Hello</h1>
        <Router>
        <Switch>
          <Route exact path="/" component={ListProductComponent}/>
          <Route exact path="/products" component={ListProductComponent}/>
          <Route exact path="/products/:prodId" component={ProductComponent}/>
          <Route exact path="/productsearch" component={SearchComponent}/>
          <Route path="/productSearch/:prodName" component={DisplayComponent}/>
        </Switch>
        </Router>
      </div>
    );
  }
}
export default App
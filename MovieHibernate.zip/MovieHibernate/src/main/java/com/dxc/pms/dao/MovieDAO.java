package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movie;

public interface MovieDAO {
		public Movie getMovie(int movieID);
		public List<Movie> getAllMovies();
		public void addMovie(Movie movie);
		public void deleteMovie(int movieID);
		public void updateMovie(Movie movie);
		public boolean isPMovieExists(int movieID);
}

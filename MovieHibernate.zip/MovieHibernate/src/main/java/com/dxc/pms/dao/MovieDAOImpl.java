package com.dxc.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.Movie;
import com.dxc.pms.model.Product;
import com.dxc.pms.util.HibernateUtil;

public class MovieDAOImpl implements MovieDAO {
	SessionFactory sf=HibernateUtil.getSessionFactory();

	@Override
	public Movie getMovie(int movieID) {
		Session session=sf.openSession();
		Movie movie=(Movie)session.get(Movie.class,movieID);
		// TODO Auto-generated method stub
		return movie;
	}

	@Override
	public List<Movie> getAllMovies() {
		// TODO Auto-generated method stub
		Session session=sf.openSession();

        Query query=session.createQuery("from Movie");
        
	return query.list();
	}

	@Override
	public void addMovie(Movie movie) {
		Session session=sf.openSession();
   		Transaction transaction=session.beginTransaction();
   		session.save(movie);
   		transaction.commit();
   		session.close();
   		System.out.println(movie.getMovieName()+" Saved Successfully");

		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMovie(int movieID) {
		Session session=sf.openSession();
   		Transaction transaction=session.beginTransaction();
   		Movie movie=new Movie();
   		movie.setMovieID(movieID);
   		session.delete(movie);
   		transaction.commit();
   		session.close();		
	}

	@Override
	public void updateMovie(Movie newmovie) {
		Session session=sf.openSession();
   		Transaction transaction=session.beginTransaction();
   		session.update(newmovie);
			
	}

	@Override
	public boolean isPMovieExists(int movieID) {
Session session=sf.openSession();
		
		Movie movie=(Movie)session.get(Movie.class,movieID);
		if(movie==null) {
		       return false;}
		else
			return true;
	}

}

package com.dxc.pms.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class HibernateUtil {
	 public static SessionFactory getSessionFactory( )
	    {
	OgmConfiguration cfg =new OgmConfiguration();
	cfg.configure();
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	return factory;

}}

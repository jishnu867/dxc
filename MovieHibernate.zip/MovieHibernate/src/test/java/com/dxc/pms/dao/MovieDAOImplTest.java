package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movie;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
	MovieDAOImpl impl;
	protected void setUp(){
   	 impl=new MovieDAOImpl();
    }
	public void testGetMovie() {
 
		Movie movie=new Movie(32323, "fvfvf", 55656, "dcfffv");
		impl.addMovie(movie);
		Movie getMovie=impl.getMovie(1111);
		assertEquals(getMovie, movie);
}

	public void testGetAllMovies() {
		int size1=impl.getAllMovies().size();
		Movie movie=new Movie(88,"har",11,"Name");
		impl.addMovie(movie);
		int size2=impl.getAllMovies().size();
		assertNotSame(size2,size1);
	}

	public void testAddMovie() {
		Movie movie =new Movie(12,"eggg",21,"jkk");
		List<Movie>allMovies1=impl.getAllMovies();
		impl.addMovie(movie);
		List<Movie>allMovies2=impl.getAllMovies();
		assertNotSame(allMovies2.size(), allMovies1.size());
	}

	public void testDeleteMovie() {
		List<Movie>beforeDelete=impl.getAllMovies();
		impl.deleteMovie(222);
		List<Movie>afterDelete=impl.getAllMovies();
		assertEquals(beforeDelete.size()-1, afterDelete.size());
	}

	public void testUpdateMovie() {
		Movie movie=new Movie(323, "rfvtt", 4778444, "frfv");
		impl.addMovie(movie);
		Movie updateMovie=new Movie(34343,"rvtbtb",6565,"ecc");
		impl.updateMovie(updateMovie);
		assertEquals(updateMovie.getMovieName(),"44444");
	}

	public void testIsPMovieExists() {
		Movie movie =new Movie(323, "wdervr", 3232, "scecv");
		impl.addMovie(movie);
		assertEquals(true, true);
	}

}

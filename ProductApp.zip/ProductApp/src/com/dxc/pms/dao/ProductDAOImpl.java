package com.dxc.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {

	private static final String FETCH_PRODUCT_ALL = "select * from product";
	private static final String FETCH_PRODUCT_BY_ID="select *from product where productId=?";
	private static final String DELETE_PRODUCT="delete from product where productId=?";
	private static final String UPDATE_PRODUCT="update product set productName=?,quantity=?,price=? where productId=? ";
	private Product product=new Product();
	Connection connection = DBConnection.getConnection();
	
	List<Product> allProducts = new ArrayList<Product>();

	public ProductDAOImpl() {

	}

	@Override
	public Product getProduct(int productId) {
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement(FETCH_PRODUCT_BY_ID);
			statement.setInt(1, productId);
			ResultSet resultSet=statement.executeQuery();
			resultSet.next();
			product.setProductId(resultSet.getInt(1));
			product.setProductName(resultSet.getString(2));
			product.setQuantityOnHand(resultSet.getInt(3));
			product.setPrice(resultSet.getInt(4));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;

	}

	@Override
	public List<Product> getAllProducts() {
		List<Product>allProducts=new ArrayList<Product>();
	
		try {
		Statement stat = connection.createStatement();
		
		ResultSet res = stat.executeQuery(FETCH_PRODUCT_ALL);
		while(res.next())
		{
			Product product=new Product();
			product.setProductId(res.getInt(1));
			product.setProductName(res.getString(2));
			product.setQuantityOnHand(res.getInt(3));
			product.setPrice(res.getInt(4));
			allProducts.add(product);
		}
		}catch(SQLException e)
	{
		e.printStackTrace();
	}
	return allProducts;
	}

	@Override
	public void addProduct(Product product) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into product values(?,?,?,?)");
			preparedStatement.setInt(1, product.getProductId());
			preparedStatement.setString(2, product.getProductName());
			preparedStatement.setInt(3, product.getQuantityOnHand());
			preparedStatement.setInt(4, product.getPrice());

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void deleteProduct(int productId) {
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(DELETE_PRODUCT);
			preparedStatement.setInt(1,productId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

	@Override
	public void updateProduct(Product product) {
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(UPDATE_PRODUCT);
			preparedStatement.setInt(4, product.getProductId());
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setInt(2, product.getQuantityOnHand());
			preparedStatement.setInt(3, product.getPrice());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean isProductExists(int productId) {
		
		return false;
	}

}

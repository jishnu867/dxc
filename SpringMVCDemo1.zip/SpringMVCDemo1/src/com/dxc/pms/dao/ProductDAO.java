package com.dxc.pms.dao;

import com.model.Product;

public interface ProductDAO {
	public boolean addProduct(Product product) ;

}

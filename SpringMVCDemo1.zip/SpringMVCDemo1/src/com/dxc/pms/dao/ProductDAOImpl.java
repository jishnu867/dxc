package com.dxc.pms.dao;

import com.model.Product;

public class ProductDAOImpl implements ProductDAO {
	
	public boolean addProduct(Product product)  {
		System.out.println("Insider DAO product"+product);
		return false;
	}

}

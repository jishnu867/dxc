package com.dxc.pms.service;

import com.model.Product;

public interface ProductService {
	
	public boolean addProduct(Product product);

}

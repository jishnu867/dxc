package com.dxc.pms.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.dxc.pms.dao.ProductDAO;
import com.model.Product;

public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO productDAO;
	
	@Override
	public boolean addProduct(Product product) {
		System.out.println("Insider product service:"+product);
		productDAO.addProduct(product);
		return false;
	}
}

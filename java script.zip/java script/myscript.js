 function check()
    {
        var uname1=(document.getElementById("username").value);
            var uname2=(document.getElementById("password").value);
            var span1=document.getElementById("span1")
            var span2=document.getElementById("span2")
            var span3=document.getElementById("span3")
            var span4=document.getElementById("span5")
            var span5=document.getElementById("span5")
         span1.innerHTML=" ";
         span2.innerHTML=" ";
         span3.innerHTML=" ";
         span4.innerHTML=" ";
         span5.innerHTML=" ";
            if(uname1.length==0 )
            {
                span1.innerHTML="<font color=green>enter the username</font>";
                return false
            }
            
            
            
            else if (uname2.length == 0)
            {
               
                span3.innerHTML="enter the password";
                return false
            }
           
            else 
            {
                if(((uname2.charAt(0)) !== 'a') && ((uname2.length)<6  || (uname2.length)>12))
                
            {
               
           span5.innerHTML="enter the password that has more than 6 and starts with a ";
           return false
            }
           else if( (uname2.charAt(0)) !== 'a')  
           {
           
           span2.innerHTML="enter the password that starts with a ";
           return false
           
            }
          
            else if ( (uname2.length)<6 || (uname2.length)>12 )
            
            {
                
           span4.innerHTML="enter the password that has more than 6 digits ";
           return false
            }
            
            else
            {
                return true
            }
           
                }
               
            
    }   
           
            
    
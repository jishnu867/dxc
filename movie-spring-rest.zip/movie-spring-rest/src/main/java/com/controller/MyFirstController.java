package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class MyFirstController {

	/* @RequestMapping("/neha") public String gg() { return "watch"; } */
	 
	 @RequestMapping("/jay") public String jj() { return "mohit"; }
	
	@RequestMapping("/neha")
	public ModelAndView gg()
	{
		String message="Lets start the party";
		ModelAndView view=new ModelAndView();
		view.setViewName("watch");
		view.addObject("msg",message);
		return view;
	}
	
	
}

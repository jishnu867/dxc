package com.dxc.dao;

import java.util.List;


import com.model.User;

public interface UserDAO {
	public boolean addUser(User user);
	public boolean isUserExistsWithPassword(String username,String password);
	public boolean isUserExists(String username);
	
	
}

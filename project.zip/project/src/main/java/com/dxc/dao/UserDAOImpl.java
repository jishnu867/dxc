package com.dxc.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.User;

@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public boolean addUser(User user) {
		mongoTemplate.save(user);
		return true;

	}

	@Override
	public boolean isUserExistsWithPassword(String username, String password) {
		User user = mongoTemplate.findById(username, User.class, "user");
		if(user == null) {
			return false;
		}
		if (user.getUsername() == username && user.getPassword() == password)
			return true;
		else
			return false;

	}

	@Override
	public boolean isUserExists(String username) {
		User user = mongoTemplate.findById(username, User.class, "user");

		if (user == null)
			return false;
		else
			return true;
	}

}

package com.dxc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.dao.UserDAO;
import com.model.User;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("Inside user service"+user);
		
		return userDAO.addUser(user);
	}

	

	@Override
	public boolean isUserExistsWithPassword(String username,String password) {
		// TODO Auto-generated method stub
		return userDAO.isUserExistsWithPassword(username,password);
	}



	@Override
	public boolean isUserExists(String username) {
		// TODO Auto-generated method stub
		return userDAO.isUserExists(username);
	}



	
	
	


	
	
}
